//
//  Home_TableViewCell.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

// NOTE - THIS CODE IS ACTUALLY FOR THE CELL OF THE EVENTS PAGE, NOT THE MAIN HOME PAGE

import UIKit
protocol cellDelegate:class {
    func changeModelValue(value:Bool,indexPath:IndexPath)
}

class Home_TableViewCell: UITableViewCell {

    // label outlet for event name
    @IBOutlet weak var eventName: UILabel!
    
    // label outlet for the amount of points an event is worth
    @IBOutlet weak var heartButton: UIButton!
    
    @IBOutlet weak var eventRewardVal: UILabel!
    weak var delegate:cellDelegate?
    // label outlet for time of event
    @IBOutlet weak var eventTime: UILabel!
    
    // label outlet for location of event
    @IBOutlet weak var eventLocation: UILabel!
    var model:eventInfo?
    var imageSelected:Bool?
    var indexPath:IndexPath?
    // action outlet for checkin button
    @IBAction func checkinButton(_ sender: UIButton) {
        if imageSelected == true{
            self.heartButton.setImage(UIImage(named: "unfavorite"), for: .normal)
        }else{
            self.heartButton.setImage(UIImage(named: "icons8-heart-outline-64"), for: .normal)
        }
        self.imageSelected  = !self.imageSelected!
        self.delegate?.changeModelValue(value: imageSelected!, indexPath: indexPath!)
    }
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    func initialise(model:eventInfo){
        self.eventName.text = model.name
        self.eventTime.text = model.startTime + "-" +  model.endTime
        self.eventRewardVal.text = model.numRewards
        self.eventLocation.text =  model.building + "/" + model.roomNum
    }
    
    
}
