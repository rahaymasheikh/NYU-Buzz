//
//  UserAccount.swift
//  NYU-Buzz
//
//  Created by Sai on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import Foundation
import UIKit
import FirebaseDatabase

public class UserAccount {
    
    let key: String!
    let itemRef: DatabaseReference?
    let username: String!
    let email: String!
    
    var points: Int
    //var rewards: String! /////make a class"??
    var events = [Event]()
    
    init(n: String, e: String){
        self.username = n
        self.email = e
        self.points = 0
        self.itemRef = nil
        self.key = ""
    }
    
    init(n: String, e: String, p: Int, eventArr: [Event]){
        self.username = n
        self.email = e
        self.points = p
        self.events = eventArr
        self.itemRef = nil
        self.key = ""
    }
    
    init(snap: DataSnapshot){ //Change all to dict
        key = snap.key
        itemRef = snap.ref
        if let dictN = snap.value as? NSDictionary, let uName = dictN["username"] as? String {
            self.username = uName
        }
        else{
            self.username = "fake"
        }
        if let dictE = snap.value as? NSDictionary, let uEmail = dictE["email"] as? String {
            self.email = uEmail
        }
        else{
            self.email = "fake"
        }
        if let dictP = snap.value as? NSDictionary, let uPoint = dictP["points"] as? Int {
            self.points = uPoint
        }
        else{
            self.points = 0
        }
        if let dictEventsUser = snap.value as? NSDictionary, let uEvents = dictEventsUser["events"] as? NSArray{
            let dbRef = Database.database().reference().child("allEvents")
            dbRef.observeSingleEvent(of: .value) { (snapshot: DataSnapshot) in
                if let dictEvents = snapshot.value as? NSDictionary, let allEvents = dictEvents["name"] as? NSArray{
                    for eventName in allEvents{
                        for eventStr  in uEvents {
                            if(eventStr as! String == eventName as! String){
                                let newUserEvent = Event(snap: snapshot)
                                self.events.append(newUserEvent)
                            }
                        }
                    }
                }
            }
        }
        else {
            self.events = [Event]()
        }
    }
    
    /*public func encode(with aCoder: NSCoder) {
     aCoder.encode(username, forKey: "username")
     aCoder.encode(email, forKey: "email")
     aCoder.encode(points, forKey: "points")
     //aCoder.encode(events, forKey: "events")
     }
     
     
     required public convenience init?(coder aDecoder: NSCoder) {
     let nameC = aDecoder.decodeObject(forKey: "username") as! String
     let emailC = aDecoder.decodeObject(forKey: "email") as! String
     let pointsC = aDecoder.decodeObject(forKey: "points") as! Int
     //let eventsC = aDecoder.decodeObject(forKey: "events") as! [Event]
     self.init(n: nameC, e: emailC, p: pointsC/*, eventArr: eventsC*/)
     }*/
    
    /*func addEvent
     func removeEvent
     func redeemReward () {
     self.points = self.points - Event.rewardPoints
     rewards += reward.name
     }*/
    
}
