//
//  myRewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class myRewardsViewController: UIViewController {

 

    override func viewDidLoad() {
//        rewardsSegController.selectedSegmentIndex = 1
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
}



//    @IBOutlet weak var rewardsSegController: UISegmentedControl!
//
//    @IBAction func goBackToRewards(_ sender: UISegmentedControl) {
//        switch rewardsSegController.selectedSegmentIndex{
//        case 0:
//            // display "all rewards view after clicking 'redeem rewards' "
//            let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "rewardsView") as UIViewController
//
//            self.present(viewController, animated: true, completion: nil)
//
//        default:
//            break;
//        }
//    }
