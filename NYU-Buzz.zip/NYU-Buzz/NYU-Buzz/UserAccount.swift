//
//  UserAccount.swift
//  NYU-Buzz
//
//  Created by Sai on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import Foundation
import UIKit

public class UserAccount {
    var username: String!
    var email: String!
    var points: Int
    var rewards: String! /////make a class"??
    var events = [Event]()
    
    //var points: Event
    init(uName: String, e: String){
        username = uName
        email = e
        points = 0
        
    }
    init(){
        username = "uName"
        email = ""
        points = 0
    }
    /*func addEvent
    func removeEvent
    func redeemReward () {
        self.points = self.points - Event.rewardPoints
        rewards += reward.name
    }*/
}
