//
//  Event.swift
//  NYU-Buzz
//
//  Created by Sai on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import Foundation
import UIKit

public class Event {
    var eventName: String!
    var description: String!
    var category: String!
    //var date??
    //var location
    var rewardPoints: Int
    
   public init(n: String, descrip: String, cate: String) {
        eventName = n
        description = descrip
        category = cate
        rewardPoints = 10
    }
    
    func setCategory(cate: String) {
        self.category = cate
    }
}
