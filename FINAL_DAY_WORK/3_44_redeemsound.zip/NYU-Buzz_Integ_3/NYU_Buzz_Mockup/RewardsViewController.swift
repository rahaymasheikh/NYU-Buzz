//
//  RewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit
import AVFoundation

class RewardsViewController: UIViewController {
    
    var redeemSound = URL(fileURLWithPath: Bundle.main.path(forResource: "cash_register", ofType: "wav")!)
    var audioPlayer = AVAudioPlayer()

    @IBOutlet weak var numCurrentTokens: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
//    @IBOutlet weak var rewardsSegController: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // set up sounds playing
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: redeemSound)
            // audioPlayer.play()
        } catch {
            print("ERROR: couldn't load 'redeemSound'!")
        }
        
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
        usernameLabel.text = tabBar.myUsername
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
    // Dictionary to hold values of reward types
    var rewardDict: [String:Int] = [
        "Dining Dollars" : 10,
        "Skirball Ticket Discount" : 20,
        "NYU Sweatshirt" : 45,
        "NYU Waterbottle": 30
    ]
    
//    @IBAction func changeView(_ sender: Any) {
//        switch rewardsSegController.selectedSegmentIndex{
//            case 1:
//                // display "my rewards view after clicking the segment controller"
//
//                let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "myrewardsView") as UIViewController
//
//                self.present(viewController, animated: true, completion: nil)
//
//
//        default:
//            break
//        }
//    }
    
    
    // action after clicking "Collect" --> displays alert confirmation that rewards are added to their account
    
    // redemption of dining dollars
    @IBAction func collectDiningDollars(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["Dining Dollars"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned $5 in dining dollars", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            self.present(alertController, animated: true, completion: nil)
            
            
            takeAwayTokens(amount: rewardDict["Dining Dollars"]!)
            tabBar.myEarnedRewards.append("$5 in Dining Dollars")
            
            audioPlayer.play()
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    // redemption of skirball discount
    @IBAction func collectSkirballTickets(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["Skirball Ticket Discount"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned 25% off a skirball ticket", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            takeAwayTokens(amount: rewardDict["Skirball Ticket Discount"]!)
            tabBar.myEarnedRewards.append("25% Off A Skirball Ticket")
            
            audioPlayer.play()
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    // redemption of nyu sweatshirt
    @IBAction func collectNYUsweatshirt(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["NYU Sweatshirt"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned an NYU Sweatshirt", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            takeAwayTokens(amount: rewardDict["NYU Sweatshirt"]!)

            tabBar.myEarnedRewards.append("NYU Sweatshirt")
            
            audioPlayer.play()
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    
    
    // redemption of nyu waterbottle
    @IBAction func collectNYUwaterbottle(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["NYU Waterbottle"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned an NYU Waterbottle", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            takeAwayTokens(amount: rewardDict["NYU Waterbottle"]!)
            tabBar.myEarnedRewards.append("NYU Waterbottle")
            
            audioPlayer.play()
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    // takes away x tokens, updates view
    func takeAwayTokens(amount: Int){
        let tabBar = tabBarController as! BaseTabBarController
        tabBar.myTokens -= amount
        numCurrentTokens.text = String(tabBar.myTokens)
    }
}
