//
//  myRewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class myRewardsViewController: UIViewController {
    @IBOutlet weak var rewardsTableView: UITableView!
    @IBOutlet weak var tokensLabel: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let tabBar = tabBarController as! BaseTabBarController
        tokensLabel.text = String(tabBar.myTokens)
        usernameLabel.text = tabBar.myUsername
        
        //init. self as delegate for tableView
        rewardsTableView.delegate = self
        rewardsTableView.dataSource = self
        
        // TRYING: set the tabbarcontroller's delegate to self
        tabBar.delegate = self
    }
 
}


extension myRewardsViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let tabBar = tabBarController as! BaseTabBarController
        print("length of myEarnedRewards is " + String(tabBar.myEarnedRewards.count))
        return tabBar.myEarnedRewards.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let tabBar = tabBarController as! BaseTabBarController
        print("creating tableview cell for " + tabBar.myEarnedRewards[indexPath.row])

        let cell = tableView.dequeueReusableCell(withIdentifier: "Rewards_TableViewCell", for: indexPath) as!  Rewards_TableViewCell
        cell.rewardTitleLabel.text = tabBar.myEarnedRewards[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }

}

extension myRewardsViewController:UITabBarControllerDelegate {
    func tabBarController(_ tabBarController: UITabBarController, didSelect viewController: UIViewController) {
        let tabBar = tabBarController as! BaseTabBarController
        self.tokensLabel.text = String(tabBar.myTokens)
        self.usernameLabel.text = tabBar.myUsername
        
        //init. self as delegate for tableView
        rewardsTableView.delegate = self
        rewardsTableView.dataSource = self
        
        rewardsTableView.reloadData()
    }
}

