//
//  Rewards_TableViewCell.swift
//  NYU_Buzz_Mockup
//
//  Created by Rohit on 16/5/2019.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class Rewards_TableViewCell: UITableViewCell {

    @IBOutlet weak var rewardTitleLabel: UILabel!
    @IBOutlet weak var rewardTitleImage: UIImageView!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
