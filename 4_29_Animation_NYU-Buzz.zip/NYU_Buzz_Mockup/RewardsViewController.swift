//
//  RewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class RewardsViewController: UIViewController {

    @IBOutlet weak var numCurrentTokens: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
    @IBOutlet weak var redeemOutletDining: UIButton!
    @IBOutlet weak var redeemOutletSkirball: UIButton!
    @IBOutlet weak var redeemOutletSweatshirt: UIButton!
    @IBOutlet weak var redeemOutletWater: UIButton!
    
    @IBOutlet weak var visualEffectView: UIVisualEffectView!
    @IBOutlet var alertView: UIView!
    
    
    @IBOutlet weak var alertTitle: UILabel!
    @IBOutlet weak var alertMessage: UILabel!
    @IBOutlet weak var alertButton: UIButton!
    //    var effect: UIVisualEffect!
    
    
//    @IBOutlet weak var rewardsSegController: UISegmentedControl!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        visualEffectView.isHidden = true
        alertView.layer.cornerRadius = 5
        redeemOutletDining.layer.cornerRadius = 5
        redeemOutletSkirball.layer.cornerRadius = 5
        redeemOutletSweatshirt.layer.cornerRadius = 5
        redeemOutletWater.layer.cornerRadius = 5
        
        
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
        usernameLabel.text = tabBar.myUsername
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
    // Dictionary to hold values of reward types
    var rewardDict: [String:Int] = [
        "Dining Dollars" : 10,
        "Skirball Ticket Discount" : 20,
        "NYU Sweatshirt" : 45,
        "NYU Waterbottle": 30
    ]
    

    func animateIn(){
        self.view.addSubview(alertView)
        alertView.center = self.view.center
        
        alertView.transform = CGAffineTransform.init(scaleX: 1.3, y:1.5)
        alertView.alpha = 0
        
        UIView.animate(withDuration: 0.4){
            self.visualEffectView.isHidden = false
            self.alertView.alpha = 1
            self.alertView.transform = CGAffineTransform.identity
        }
        
    }
    
    func animateOut(){
        UIView.animate(withDuration: 0.3, animations: {
            self.alertView.transform = CGAffineTransform.init(scaleX: 1.3, y: 1.5)
            self.alertView.alpha = 0
            self.visualEffectView.isHidden = true
            
        }) { (success: Bool) in self.alertView.removeFromSuperview() }
    }
    
    @IBAction func dissmissAlert(_ sender: Any) {
        animateOut()
    }
    
    
    // action after clicking "Collect" --> displays alert confirmation that rewards are added to their account
    var success = ""
    var message = ""
    var buttonMessage = ""
    
    // redemption of dining dollars
    @IBAction func collectDiningDollars(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController

        if (tabBar.myTokens >= rewardDict["Dining Dollars"]!){
            success = "Success!"
            message = "You earned $5 in Dining Dollars"
            buttonMessage  = "Ok, awesome."
            
            takeAwayTokens(amount: rewardDict["Dining Dollars"]!)
            tabBar.myEarnedRewards.append("$5 in Dining Dollars")

        }
        else{
            success = "Oops!"
            message = "You dont have enough rewards to redeem this prize."
            buttonMessage  = "Dismiss"
        }
        alertTitle.text = success
        alertMessage.text = message
        alertButton.setTitle(buttonMessage , for: .normal)
        
        animateIn()
    }
    
    // redemption of skirball discount
    @IBAction func collectSkirballTickets(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["Skirball Ticket Discount"]!){
            success = "Success!"
            message = "You earned 25% off a skirball ticket"
            buttonMessage  = "Ok, awesome."
            
            takeAwayTokens(amount: rewardDict["Skirball Ticket Discount"]!)
            tabBar.myEarnedRewards.append("25% Off A Skirball Ticket")
        }
        else{
            success = "Oops!"
            message = "You dont have enough rewards to redeem this prize."
            buttonMessage  = "Dismiss"
        }
        alertTitle.text = success
        alertMessage.text = message
        alertButton.setTitle(buttonMessage , for: .normal)
        
        animateIn()

    }
    
    // redemption of nyu sweatshirt
    @IBAction func collectNYUsweatshirt(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["NYU Sweatshirt"]!){
            success = "Success!"
            message = "You earned an NYU Sweatshirt"
            buttonMessage  = "Ok, awesome."
            
            takeAwayTokens(amount: rewardDict["NYU Sweatshirt"]!)
            tabBar.myEarnedRewards.append("NYU Sweatshirt")
        }
        else{
            success = "Oops!"
            message = "You dont have enough rewards to redeem this prize."
            buttonMessage  = "Dismiss"
        }
        alertTitle.text = success
        alertMessage.text = message
        alertButton.setTitle(buttonMessage , for: .normal)
        
        animateIn()
    }
    
    
    // redemption of nyu waterbottle
    @IBAction func collectNYUwaterbottle(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["NYU Waterbottle"]!){
            success = "Success!"
            message = "You earned an NYU Waterbottle"
            buttonMessage  = "Ok, awesome."
            
            takeAwayTokens(amount: rewardDict["NYU Waterbottle"]!)
            tabBar.myEarnedRewards.append("NYU Waterbottle")
            
        }
        else{
            success = "Oops!"
            message = "You dont have enough rewards to redeem this prize."
            buttonMessage  = "Dismiss"
        }
        alertTitle.text = success
        alertMessage.text = message
        alertButton.setTitle(buttonMessage , for: .normal)
        
        animateIn()
    }
    
    // takes away x tokens, updates view
    func takeAwayTokens(amount: Int){
        let tabBar = tabBarController as! BaseTabBarController
        tabBar.myTokens -= amount
        numCurrentTokens.text = String(tabBar.myTokens)
    }
}
