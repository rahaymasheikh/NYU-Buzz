//
//  BaseTabBarController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/12/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class BaseTabBarController: UITabBarController {

    
    var myTokens: (Int) = 0
    var myUsername: (String) = "nyuStudent123"
    var myEarnedRewards: [String] = [String]()
    var eventObjArray: [Any] = [Any]()
    var favoriteEvents: [Any] = [Any]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
}
