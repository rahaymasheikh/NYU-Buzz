//
//  AddEventViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

// UIViewController code adapted from tutorial found on: codewithchris.com/uipickerview-example/

import UIKit

struct eventInfo {
    var name:       String = ""
    var roomNum:    String = ""
    var numRewards: String = ""
    var building:   String = ""
    var startDate:  String = ""
    var endDate:    String = ""
    var startTime:  String = ""
    var endTime:    String = ""
    var category:   String = ""
    var imageSelected:Bool = false
    
    mutating func setImageSelected(value:Bool){
        self.imageSelected = value
    }
    
}
//class DatePicker: UIDatePicker{
//    override func layoutSubviews() {
//        super.layoutSubviews()
//
//        backgroundColor = UIColor.black.withAlphaComponent(0.6)
//        setValue(false, forKey: "highlightsToday")
//        setValue(UIColor.white, forKey: "textColor")
//    }
//}

protocol AddEventViewControllerDelegate:class{
    func sendEvent(event:eventInfo)
}

class AddEventViewController: UIViewController, UIPickerViewDelegate,
UIPickerViewDataSource {
    
    @IBOutlet weak var eventName: UITextField!
    @IBOutlet weak var roomNumber: UITextField!
    @IBOutlet weak var numRewards: UITextField!
    
    @IBOutlet weak var timePicker: UIDatePicker!
    @IBOutlet weak var endTimePicker: UIDatePicker!
    
    @IBOutlet weak var categoryPicker: UIPickerView!
    @IBOutlet weak var buildingPicker: UIPickerView!
    
    
    var categoryPickerData: [String] = [String]()
    var buildingPickerData: [String] = [String]()
    weak var delegate:AddEventViewControllerDelegate?
    override func viewDidLoad() {
        super.viewDidLoad()
        categoryPickerData = ["Wellness", "Cultural", "Religious", "Academic",
                              "Athletic", "Food", "Entertainment", "Career",
                              "Other"]
        
        buildingPickerData = ["Courant", "GCASL", "Kimmel", "Laguard. Coop"]
        // Connect the data for the Building Data:
        self.buildingPicker.delegate = self
        self.buildingPicker.dataSource = self
        
        // Connect the data for the category Data:
        self.categoryPicker.delegate = self
        self.categoryPicker.dataSource = self
        
        
        // Add categorical data to array:
       
        
        self.categoryPicker.backgroundColor = UIColor.black.withAlphaComponent(0.1)
//        self.categoryPicker.setValue(false, forKeyPath: "highlightsToday")
//        self.categoryPicker.setValue(UIColor.white, forKeyPath: "textColor")
        
        self.buildingPicker.backgroundColor = UIColor.black.withAlphaComponent(0.1)
        
        timePicker.setValue(UIColor.white, forKeyPath: "textColor")
        timePicker.setValue(false, forKeyPath: "highlightsToday")
        
        endTimePicker.setValue(UIColor.white, forKeyPath: "textColor")
        endTimePicker.setValue(false, forKeyPath: "highlightsToday")
        
        // INIT. event fields
        event.name = ""
        event.building = buildingPickerData[0]
        event.category = categoryPickerData[0]
        event.startDate = "\(timePicker.date)"
        let dateFormatter_startDate = DateFormatter()
        let dateFormatter_startTime = DateFormatter()
        
        dateFormatter_startDate.dateFormat = "MM-dd-YYY"
        dateFormatter_startTime.dateFormat = "hh:mm a"
        
        let formatted_startDate = dateFormatter_startDate.string(from: timePicker.date)
        let formatted_startTime = dateFormatter_startTime.string(from: timePicker.date)
        event.startDate = formatted_startDate
        event.startTime = formatted_startTime
        
        let formatted_endDate = dateFormatter_startDate.string(from: endTimePicker.date)
        let formatted_endTime = dateFormatter_startTime.string(from: endTimePicker.date)
        event.endDate = formatted_endDate
        event.endTime = formatted_endTime
    }
    
    // dismiss keyboard if touching outside of fields
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    var event = eventInfo()
    
    var eventInfoArray: [eventInfo] = [eventInfo]()

    
    // Building and Category
    // ------------------------------------
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Number of columns of data
    func numberOfComponents(in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    // The number of rows of data
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView.tag == 1 {
            return buildingPickerData.count
        } else {
            return categoryPickerData.count
        }
    }
    
    
//     Data for row and column that's being passed in
    func pickerView(_ pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        
        if pickerView.tag == 1{
            return NSAttributedString(string: buildingPickerData[row],
                                      attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
            
        }
        else{
            return NSAttributedString(string: categoryPickerData[row],
                                      attributes: [NSAttributedString.Key.foregroundColor: UIColor.white])
        }
        
    }
    
    // storing data for building and category to the event object
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        
        switch pickerView {
        case buildingPicker:
            event.building = buildingPickerData[row]
        case categoryPicker:
            event.category = categoryPickerData[row]
        default:
            break
        }
        
    }
    
    // Date
    // ------------------------------------
    // get the STARTING end and start Date and Times and and add the
    @IBAction func getDate(_ sender: UIDatePicker) {
        let dateFormatter_startDate = DateFormatter()
        let dateFormatter_startTime = DateFormatter()

        dateFormatter_startDate.dateFormat = "MM-dd-YYY"
        dateFormatter_startTime.dateFormat = "hh:mm a"

        let formatted_startDate = dateFormatter_startDate.string(from: timePicker.date)
        let formatted_startTime = dateFormatter_startTime.string(from: timePicker.date)

        event.startDate = formatted_startDate
        event.startTime = formatted_startTime
        print(event.startDate)
        print(event.startTime)
    }
    
    // get the ENDING end and start Date and Times and and add the
    @IBAction func getEndDate(_ sender: UIDatePicker) {
        let dateFormatter_endDate = DateFormatter()
        let dateFormatter_endTime = DateFormatter()
        
        dateFormatter_endDate.dateFormat = "MM-dd-YYY"
        dateFormatter_endTime.dateFormat = "hh:mm a"
        
        let formatted_endDate = dateFormatter_endDate.string(from: endTimePicker.date)
        let formatted_endTime = dateFormatter_endTime.string(from: endTimePicker.date)
        
        event.endDate = formatted_endDate
        event.endTime = formatted_endTime
        print(event.endDate)
        print(event.endTime)
    }
    
    // After hitting submit, check if name and room are empty.. if not, set properties to event and add the event object to the event array
    @IBAction func submit(_ sender: UIButton) {
        // Event Name
        if (!(eventName.text!.isEmpty)){
            event.name = eventName.text!
        }
        // Number of rewards
        if (!(numRewards.text!.isEmpty)){
            event.numRewards = numRewards.text!
        }
        // Event Room
        if (!(roomNumber.text!.isEmpty)){
            event.roomNum = roomNumber.text!
        }

        delegate?.sendEvent(event: event)
        dismiss(animated: true, completion: nil)
    }
    
}


