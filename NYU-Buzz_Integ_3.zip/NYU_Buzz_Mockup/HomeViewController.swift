//
//  HomeViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit
import CoreLocation

class HomeViewController: UIViewController {
    @IBOutlet weak var usernameOutlet: UILabel!
    @IBOutlet weak var currentRewardsValOutlet: UILabel!
    @IBOutlet weak var currentDateOutlet: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    var events:[eventInfo] = []
    var currentTokens: Int = 0
    
    // dict of locationName:long/latitude
    var nyuLocDict: [String: CLLocation] = [
        "GCASL": CLLocation(latitude: 40.730060, longitude: -73.998028),
        "Kimmel": CLLocation(latitude: 40.730014, longitude: -73.997782),
        "Courant": CLLocation(latitude: 40.728691764898265, longitude: -73.99566113948822)
    ]
    let locationManager = CLLocationManager();  // we use locationManager to retrieve location info
    let geoCoder = CLGeocoder(); // we use geoCoder to convert coordinates to an address
    let addressDist: Double = 100;      // distance in meters for two CLLocations to be within each other to be considered the same address
        
//    @IBAction func logoutButton(_ sender: Any) {
//    }
//
  override func viewDidLoad() {
        super.viewDidLoad()
    
        // set precision of locationManager
        locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters
    
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
        usernameOutlet.text = tabBar.myUsername
        self.tableView.delegate = self
        self.tableView.dataSource = self
    
        // init. things for locationManager
        locationManager.delegate = self;
        // ask to updateLocAuthoriz status
        locationManager.requestWhenInUseAuthorization();
    
        // update currentDate
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "MM/dd/yyyy"
        let strFromToday = dateFormatter.string(from: Date())
        currentDateOutlet.text = strFromToday
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
    }
    
    @IBAction func checkInButton(_ sender: Any) {
        userCheckIn()
    }
    
}

extension HomeViewController:CLLocationManagerDelegate {
    // called if loc authoriz. status is changed, updates locAuthStatus
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        print("loc authZ status: \(status)")
    }
    
    // called once requestLocation is granted, displ. location to locationLabel
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let authZStatus = CLLocationManager.authorizationStatus();
        
        if (authZStatus == .authorizedAlways || authZStatus == .authorizedWhenInUse) {
            if let location = locations.first {
                // check if location, time matches with any user events
                self.checkIfAtEvent(atLocation: location, onDate: Date())
            }
        }
        else {
            print("ERROR: lacking correct locAuthZ status!")
        }
        
        // DEBUG:
        print("User loc is \(locations.first)")
    }
    
    // catches any errors thrown by locationManager calls
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("ERROR: locationManager error \(error)")
    }
    
    //////////////////////////////
    // HELPER METHODS
    //////////////////////////////
    
    // called when user presses "check-in"
    func userCheckIn(){
        locationManager.requestLocation()
    }
    
    // checks if user is at an event they subscribed for, if so, rewards user! (called after we get user location)
    func checkIfAtEvent(atLocation: CLLocation, onDate: Date) {
        var matchingEvent: eventInfo?
        var matchingEventInd: Int?
        for (index, event) in events.enumerated() {
            let eventCLLoc: CLLocation = nyuLocDict[event.building]!
            if (eventCLLoc == nil) {
                print("ERROR: couldn't find that location in nyuLocDict!")
            }
            if (atLocation.distance(from: eventCLLoc) <= addressDist) {
                if (getDate(fromDateStr: event.startDate, fromTimeStr: event.startTime)  <= onDate && onDate <= getDate(fromDateStr: event.endDate, fromTimeStr: event.endTime)) {
                    matchingEvent = event
                    matchingEventInd = index
                    break;
                }
            }
        }
        // TODO: check if matchingEvent isn't null,  if so, play alert, update tokens, delete event
        if (matchingEvent != nil) {
            let alert = UIAlertController(title: "Checked in!", message: "You have successfuly checked in for the event \(matchingEvent!.name).", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
            addTokens(tokens: Int(matchingEvent!.numRewards)!)
            deleteEvent(atIndex: matchingEventInd!)
        }
        else {
            let alert = UIAlertController(title: "No events", message: "You are not scheduled for any events at this time or location", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    // updates value and display of tokens
    func addTokens(tokens: Int) {
        let tabBar = tabBarController as! BaseTabBarController
        tabBar.myTokens += tokens
        currentRewardsValOutlet.text = String(tabBar.myTokens)
    }
    
    // deletes user event and event in display
    func deleteEvent(atIndex: Int) {
        self.events.remove(at: atIndex)
        self.tableView.reloadData()
    }
    
    // rets date obj from a strings w date format "MM-dd-yyyy" time format "hh:mm a"
    func getDate(fromDateStr: String, fromTimeStr: String) -> Date {
        let dateTimeStr = fromDateStr + " " + fromTimeStr
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone.autoupdatingCurrent
        dateFormatter.dateFormat = "MM-dd-yyyy hh:mm a"
        guard let dateFromStr = dateFormatter.date(from: dateTimeStr) else {
            fatalError()
        }
        
        return dateFromStr
    }
}

extension HomeViewController:AddEventViewControllerDelegate{
    func sendEvent(event: eventInfo) {
        self.events.append(event)
        self.tableView.reloadData()
    }
    
    
}

extension HomeViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Home_TableViewCell", for: indexPath) as!  Home_TableViewCell
        cell.model  = events[indexPath.row]
        cell.imageSelected = events[indexPath.row].imageSelected
        cell.initialise(model: events[indexPath.row])
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == UITableViewCell.EditingStyle.delete {
            events.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
        
    }
}

extension HomeViewController:cellDelegate{
    func changeModelValue(value: Bool,indexPath:IndexPath) {
        events[indexPath.row].setImageSelected(value: value)
        if (value == true){
            events.remove(at: indexPath.row)
        }
        self.tableView.reloadData()
    }
}
