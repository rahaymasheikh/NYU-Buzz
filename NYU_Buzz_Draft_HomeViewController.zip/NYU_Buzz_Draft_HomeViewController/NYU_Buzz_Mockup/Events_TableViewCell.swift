//
//  Events_TableViewCell.swift
//  NYU_Buzz_Mockup
//
//  Created by Rohit on 6/5/2019.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import Foundation
import UIKit


