//
//  myRewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class myRewardsViewController:UIViewController, UITableViewDelegate, UITableViewDataSource
{
    
    var myEarnedRewards = ["$5 Dining Dollars", "NYU Waterbottle", "NYU Sweatshirt"]


//    @IBOutlet weak var rewardsSegController: UISegmentedControl!
    @IBOutlet weak var currentRewardsValOutlet: UILabel!
    @IBOutlet weak var usernameOutlet: UILabel!
    @IBOutlet weak var myRewardsTableView: UITableView!

    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
        usernameOutlet.text = tabBar.myUsername
        
        
        myRewardsTableView.delegate = self
        myRewardsTableView.dataSource = self
//        rewardsSegController.selectedSegmentIndex = 1
        
       
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
//        let tabBar = tabBarController as! BaseTabBarController
        return myEarnedRewards.count
    }
    
    //configuring the cell
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
//        let tabBar = tabBarController as! BaseTabBarController
        let cell = tableView.dequeueReusableCell(withIdentifier: "myCell", for: indexPath) as! RewardsTableViewCell
        
        cell.rewardTitle.text = myEarnedRewards[indexPath.row]
        
        print(cell.rewardTitle.text)

        
        return cell
    }
    

}














//    @IBAction func goBackToRewards(_ sender: UISegmentedControl) {
//        switch rewardsSegController.selectedSegmentIndex{
//        case 0:
//            // display "all rewards view after clicking 'redeem rewards' "
//            let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "rewardsView") as UIViewController
//
//            self.present(viewController, animated: true, completion: nil)
//
//        default:
//            break;
//        }
//    }
