//
//  RewardsTableViewCell.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/11/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class RewardsTableViewCell: UITableViewCell {
    
    @IBOutlet weak var rewardTitle: UILabel!
    
}
