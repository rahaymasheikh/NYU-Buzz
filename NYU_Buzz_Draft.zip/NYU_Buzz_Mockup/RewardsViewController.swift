//
//  RewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class RewardsViewController: UIViewController {

    @IBOutlet weak var numCurrentTokens: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
        usernameLabel.text = tabBar.myUsername
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
    // Dictionary to hold values of reward types
    var rewardDict: [String:Int] = [
        "Dining Dollars" : 10,
        "Skirball Ticket Discount" : 20,
        "NYU Sweatshirt" : 45,
        "NYU Waterbottle": 30
    ]
    
    // action after clicking "Collect" --> displays alert confirmation that rewards are added to their account
    
    // redemption of dining dollars
    @IBAction func collectDiningDollars(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["Dining Dollars"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned $5 in dining dollars", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            self.present(alertController, animated: true, completion: nil)
            
            
            tabBar.myTokens = tabBar.myTokens - rewardDict["Dining Dollars"]!
            tabBar.myEarnedRewards.append("$5 in Dining Dollars")
            
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
    
    // redemption of skirball discount
    @IBAction func collectSkirballTickets(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["Skirball Ticket Discount"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned 25% off a skirball ticket", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            tabBar.myTokens = tabBar.myTokens - rewardDict["Skirball Ticket Discount"]!
            
            tabBar.myEarnedRewards.append("25% Off A Skirball Ticket")
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    // redemption of nyu sweatshirt
    @IBAction func collectNYUsweatshirt(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["NYU Sweatshirt"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned an NYU Sweatshirt", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            tabBar.myTokens = tabBar.myTokens - rewardDict["NYU Sweatshirt"]!
            
            tabBar.myEarnedRewards.append("NYU Sweatshirt")
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
        
    }
    
    
    // redemption of nyu waterbottle
    @IBAction func collectNYUwaterbottle(_ sender: UIButton) {
        let tabBar = tabBarController as! BaseTabBarController
        
        if (tabBar.myTokens >= rewardDict["NYU Waterbottle"]!){
            let alertController = UIAlertController(title: "Success!", message:
                "You earned an NYU Waterbottle", preferredStyle: .alert)
            
            alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
            
            self.present(alertController, animated: true, completion: nil)
            
            tabBar.myTokens = tabBar.myTokens - rewardDict["NYU Waterbottle"]!
            tabBar.myEarnedRewards.append("NYU Waterbottle")
            
        }
        else{
            let alertController = UIAlertController(title: "Oops!", message:
                "You dont have enough rewards to redeem this prize.", preferredStyle: .alert)
            alertController.addAction(UIAlertAction(title: "Dismiss", style: .default))
            self.present(alertController, animated: true, completion: nil)
        }
    }
    
    
}


//    @IBOutlet weak var rewardsSegController: UISegmentedControl!
//
//    @IBAction func changeView(_ sender: Any) {
//        switch rewardsSegController.selectedSegmentIndex{
//            case 1:
//                // display "my rewards view after clicking the segment controller"
//
//                let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "myrewardsView") as UIViewController
//
//                self.present(viewController, animated: true, completion: nil)
//
//
//        default:
//            break
//        }
//    }
