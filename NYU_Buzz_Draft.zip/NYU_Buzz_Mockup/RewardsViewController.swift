//
//  RewardsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class RewardsViewController: UIViewController {

    @IBOutlet weak var rewardsSegController: UISegmentedControl!
    
    @IBAction func changeView(_ sender: Any) {
        switch rewardsSegController.selectedSegmentIndex{
            case 1:
                // display "my rewards view after clicking the segment controller"
                
                let viewController:UIViewController = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "myrewardsView") as UIViewController
                
                self.present(viewController, animated: true, completion: nil)

    
        default:
            break
        }
    }
    
    
    // action after clicking "Collect" --> displays alert confirmation that rewards are added to their account
    
    // redemption of dining dollars
    @IBAction func collectDiningDollars(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Success!", message:
            "You earned $5 in dining dollars", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // redemption of skirball discount
    @IBAction func collectSkirballTickets(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Success!", message:
            "You earned 25% off a skirball ticket", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // redemption of nyu sweatshirt
    @IBAction func collectNYUsweatshirt(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Success!", message:
            "You earned an NYU Sweatshirt", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // redemption of nyu waterbottle
    @IBAction func collectNYUwaterbottle(_ sender: UIButton) {
        let alertController = UIAlertController(title: "Success!", message:
            "You earned an NYU Waterbottle", preferredStyle: .alert)
        
        alertController.addAction(UIAlertAction(title: "Ok, awesome.", style: .default))
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

    
}
