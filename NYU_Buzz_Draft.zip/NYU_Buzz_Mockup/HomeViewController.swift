//
//  HomeViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var usernameOutlet: UILabel!
    @IBOutlet weak var currentRewardsValOutlet: UILabel!
    @IBOutlet weak var currentDateOutlet: UILabel!
    
    @IBAction func logoutButton(_ sender: Any) {
    }
    
}
