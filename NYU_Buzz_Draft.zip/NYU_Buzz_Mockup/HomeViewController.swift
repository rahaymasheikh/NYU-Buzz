//
//  HomeViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var username: UILabel!
    @IBOutlet weak var numCurrentTokens: UILabel!
    @IBOutlet weak var currentDateOutlet: UILabel!
    
    var currentTokens: Int = 0
    
     var newEvent = Event.init(name: "event", tokens: 4)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
        username.text = tabBar.myUsername
        
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
    
    
   
    @IBAction func checkInButton(_ sender: Any) {
        let tabBar = tabBarController as! BaseTabBarController
        tabBar.myTokens = tabBar.myTokens + newEvent.tokens
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
  
    
    
//    @IBAction func logoutButton(_ sender: Any) {
//    }
    
}


class Event {
    var name: String;
    //    var location:CLLocation;
    var tokens:Int;
    var startDate:Date;
    var endDate:Date;
    
    init(name: String, tokens: Int) {
        self.name = name
        //        self.location = CLLocation()
        self.tokens = tokens
        
        // always have startDate be yesterday, endDate be tomorrow!
        let currentDate = Date()
        let yesterday: Date = Calendar.current.date(byAdding: .day, value: 1, to: currentDate)!
        let tomorrow: Date = Calendar.current.date(byAdding: .day, value: 1, to: currentDate)!
        self.startDate = yesterday
        self.endDate = tomorrow
    }
    
}
