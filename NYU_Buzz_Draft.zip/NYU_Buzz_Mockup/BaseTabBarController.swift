//
//  BaseTabBarController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/11/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class BaseTabBarController: UITabBarController {
    
    var myTokens: (Int) = 0
    var myUsername: (String) = "nyuStudent123"
    
    var myEarnedRewards: [String] = [String]()
//    var myEarnedRewards = ["$5 Dining Dollars"]

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    

}
