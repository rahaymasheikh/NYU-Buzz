//
//  EventsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class EventsViewController: UIViewController {
    
    @IBOutlet weak var currentRewardsValOutlet: UILabel!
    @IBOutlet weak var usernameOutlet: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
        usernameOutlet.text = tabBar.myUsername

        // Do any additional setup after loading the view.
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
    }
    

}
