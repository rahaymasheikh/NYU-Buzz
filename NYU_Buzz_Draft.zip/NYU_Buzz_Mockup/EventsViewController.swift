//
//  EventsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class EventsViewController: UIViewController {
    

    @IBOutlet weak var numCurrentTokens: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
    
    @IBOutlet weak var tableView: UITableView!
    
    var events:[eventInfo] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBar = tabBarController as! BaseTabBarController
        print(String(tabBar.myTokens))
        numCurrentTokens.text = String(tabBar.myTokens)
        usernameLabel.text = tabBar.myUsername
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
    
    @IBAction func addButtonTapped(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AddEventViewController") as! AddEventViewController
        controller.delegate = self
        
        self.present(controller, animated: true, completion: nil)
    }
}

extension EventsViewController:AddEventViewControllerDelegate{
    func sendEvent(event: eventInfo) {
        self.events.append(event)
        self.tableView.reloadData()
    }
    
    
}

extension EventsViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Home_TableViewCell", for: indexPath) as!  Home_TableViewCell
        cell.model  = events[indexPath.row]
        cell.imageSelected = events[indexPath.row].imageSelected
        cell.initialise(model: events[indexPath.row])
        cell.indexPath  = indexPath
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == UITableViewCell.EditingStyle.delete {
            events.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
        
        
        
    }
}

extension EventsViewController:cellDelegate{
    func changeModelValue(value: Bool,indexPath:IndexPath) {
        events[indexPath.row].setImageSelected(value: value)
    }
}
