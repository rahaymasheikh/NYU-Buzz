//
//  HomeViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    @IBOutlet weak var usernameOutlet: UILabel!
    @IBOutlet weak var currentRewardsValOutlet: UILabel!
    @IBOutlet weak var currentDateOutlet: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    var events:[eventInfo] = []
    var currentTokens: Int = 0
    var newEvent = Event.init(name: "event", tokens: 4)
        
//    @IBAction func logoutButton(_ sender: Any) {
//    }
//
  override func viewDidLoad() {
        super.viewDidLoad()
    
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
        usernameOutlet.text = tabBar.myUsername
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        currentRewardsValOutlet.text = String(tabBar.myTokens)
    }
    
    @IBAction func checkInButton(_ sender: Any) {
        let tabBar = tabBarController as! BaseTabBarController
        tabBar.myTokens = tabBar.myTokens + newEvent.tokens
        currentRewardsValOutlet.text = String(tabBar.myTokens)
    }
    
    
}

extension HomeViewController:AddEventViewControllerDelegate{
    func sendEvent(event: eventInfo) {
        self.events.append(event)
        self.tableView.reloadData()
    }
    
    
}

extension HomeViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return events.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Home_TableViewCell", for: indexPath) as!  Home_TableViewCell
        cell.model  = events[indexPath.row]
        cell.imageSelected = events[indexPath.row].imageSelected
        cell.initialise(model: events[indexPath.row])
        cell.indexPath  = indexPath
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == UITableViewCell.EditingStyle.delete {
            events.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
        
    }
}

extension HomeViewController:cellDelegate{
    func changeModelValue(value: Bool,indexPath:IndexPath) {
        events[indexPath.row].setImageSelected(value: value)
        if (value == true){
            events.remove(at: indexPath.row)
        }
        self.tableView.reloadData()
    }
}

class Event {
    var name: String;
    //    var location:CLLocation;
    var tokens:Int;
    var startDate:Date;
    var endDate:Date;
    
    init(name: String, tokens: Int) {
        self.name = name
        //        self.location = CLLocation()
        self.tokens = tokens
        
        // always have startDate be yesterday, endDate be tomorrow!
        let currentDate = Date()
        let yesterday: Date = Calendar.current.date(byAdding: .day, value: 1, to: currentDate)!
        let tomorrow: Date = Calendar.current.date(byAdding: .day, value: 1, to: currentDate)!
        self.startDate = yesterday
        self.endDate = tomorrow
    }
    
}
