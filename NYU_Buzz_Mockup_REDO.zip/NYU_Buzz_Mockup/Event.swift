//
//  Event.swift
//  NYU-Buzz
//
//  Created by Sai on 5/7/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import Foundation
import UIKit
import FirebaseDatabase

public class Event { //ADD LOCATION potential dicrip
    var name:       String!
    var roomNum:    String!
    var building:   String!
    var startDate:  String!
    var endDate:    String!
    var startTime:  String!
    var endTime:    String!
    var category:   String!
    //var description: String!
    let rewardPoints = 10
    let key: String!
    let itemRef: DatabaseReference?
    
    public init(n: String, rNum: String, b: String, sDate: String, eDate: String, sTime: String, eTime: String, cate: String) {
        self.name = n
        self.roomNum = rNum
        self.building = b
        self.startDate = sDate
        self.endDate = eDate
        self.startTime = sTime
        self.endTime = eTime
        //description = descrip
        //self.location = CLLocation()
        self.category = cate
        self.key = ""
        self.itemRef = nil
    }
    
   /* init(snap: DataSnapshot){
        key = snap.key
        itemRef = snap.ref
        
        if let dictN = snap.value as? NSDictionary, let eName = dictN["name"] as? String { ///change all to dict?????
            name = eName
        }
        else{
            name = ""
        }
        if let dictR = snap.value as? NSDictionary, let rNum = dictR["roomNumber"] as? String {
            roomNum = rNum
        }
        else{
            roomNum = ""
        }
        if let dictB = snap.value as? NSDictionary, let build = dictB["building"] as? String {
            building = build
        }
        else{
            building = ""
        }
        if let dictSD = snap.value as? NSDictionary, let sDate = dictSD["startDate"] as? String {
            startDate = sDate
        }
        else{
            startDate = ""
        }
        if let dictED = snap.value as? NSDictionary, let eDate = dictED["endDate"] as? String {
            endDate = eDate
        }
        else{
            endDate = ""
        }
        if let dictST = snap.value as? NSDictionary, let sTime = dictST["category"] as? String {
            startTime = sTime
        }
        else{
            startTime = ""
        }
        if let dictET = snap.value as? NSDictionary, let eTime = dictET["endTime"] as? String {
            endTime = eTime
        }
        else{
            endTime = ""
        }
        if let dictC = snap.value as? NSDictionary, let cate = dictC["startTime"] as? String {
            category = cate
        }
        else{
            category = ""
        }
    }*/
    
    /*public func encode(with aCoder: NSCoder) {
     aCoder.encode(name, forKey: "name")
     aCoder.encode(roomNum, forKey: "roomNumber")
     aCoder.encode(building, forKey: "building")
     aCoder.encode(startDate, forKey: "startDate")
     aCoder.encode(endDate, forKey: "endDate")
     aCoder.encode(startTime, forKey: "startTime")
     aCoder.encode(endTime, forKey: "endTime")
     aCoder.encode(category, forKey: "category")
     }
     
     required public convenience init?(coder aDecoder: NSCoder) {
     //let key = aDecoder.decodeObject(forKey: "key") as! String
     //let itemRef = aDecoder.decodeObject(forKey: "itemRef") as! DatabaseReference
     let nameC = aDecoder.decodeObject(forKey: "name") as! String
     let rNumC = aDecoder.decodeObject(forKey: "roomNumber") as! String
     let buildC = aDecoder.decodeObject(forKey: "building") as! String
     let sDateC = aDecoder.decodeObject(forKey: "startDate") as! String
     let eDateC = aDecoder.decodeObject(forKey: "endDate") as! String
     let sTimeC = aDecoder.decodeObject(forKey: "startTime") as! String
     let eTimeC = aDecoder.decodeObject(forKey: "endTime") as! String
     let cateC = aDecoder.decodeObject(forKey: "category") as! String
     self.init(n: nameC, rNum: rNumC, b: buildC, sDate: sDateC, eDate: eDateC, sTime: sTimeC, eTime: eTimeC, cate: cateC)
     }*/
}

