//
//  SignUpViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/13/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

/*import UIKit

class SignUpViewController: UIViewController {

    
    @IBOutlet weak var newUsername: UITextField!
    @IBOutlet weak var newEmail: UITextField!
    @IBOutlet weak var newPassword: UITextField!
    
    @IBAction func signUp(_ sender: Any) {
        let tabBarController = self.storyboard?.instantiateViewController(withIdentifier: "tabBarController") as! UITabBarController
        
        // FOR DEMO: set username to name in text field
        (tabBarController as! BaseTabBarController).myUsername = newUsername.text!
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        appDelegate.window?.rootViewController = tabBarController
    }
    
    // (COPY THIS TO SIGNUP VIEW CONTROLLER)
    // dismiss keyboard if touching outside of fields
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?){
        self.view.endEditing(true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
}*/
    
    

    

    


