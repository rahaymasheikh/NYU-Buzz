//
//  SignUpViewController.swift
//  NYU-Buzz
//
//  Created by Sai on 5/2/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth
import FirebaseDatabase

class Sign_UpViewController: UIViewController {
    
    @IBOutlet weak var usernameText: UITextField!
    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var signUpButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.+
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    @IBAction func signUpPressed(_ sender: Any) {
        signUp()
    }
    @IBAction func cancelSignIn(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func signUp() {
        //(ofClasses: [UserAccount], from: decoded) //as! UserAccount
        if(usernameText.text == "" || emailText.text == "" || passwordText.text == "") {
            let alertController = UIAlertController(title: "Error", message: "Please enter your usernmae, email. and password", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            present(alertController, animated: true, completion: nil)
        }
        else {
            
            Auth.auth().createUser(withEmail: self.emailText.text!, password: self.passwordText.text!) { (user, error) in
                if(error != nil){
                    print(error?.localizedDescription ?? "No description")
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    self.present(alertController, animated: true, completion: nil)
                }
                else {
                    var newUser: UserAccount!
                    let email = self.emailText.text!
                    var newEmail = ""
                    for index in email.indices {
                        if(email[index] == "@" || email[index] == ".") {
                            //skip
                        }
                        else{
                            newEmail = newEmail + String(email[index])
                        }
                    }
                    newUser = UserAccount(n: self.usernameText.text!, e: self.emailText.text!)
                    let newInfo = ["username": newUser.username, "email": newUser.email, "points": "0", "key": newEmail] //"events": "", "rewards": "",  add here potentiall????????????
                    let dbRef = Database.database().reference().child("users").child(newEmail)
                    dbRef.setValue(newInfo)
                    dbRef.child("events").setValue("")
                    dbRef.child("rewards").setValue("")
                    /*, withCompletionBlock: { (error, ref) in
                     print("Signed up user: " + (user?.user.email)!)
                     if let user = user?.user {
                     let changeRequest = user.createProfileChangeRequest()
                     changeRequest.displayName = self.usernameText.text
                     changeRequest.commitChanges { error in
                     if let error = error {
                     print(error.localizedDescription)
                     let alertController = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                     
                     let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                     alertController.addAction(defaultAction)
                     self.present(alertController, animated: true, completion: nil)
                     }
                     else { //check for same username so no overwrite?????
                     print("Profile updated")
                     let newUser = ["username": self.usernameText.text!, "email": self.emailText.text!, "events": "none", "rewards": "none", "points": "0"]
                     let dbRef = Database.database().reference().child("users").child(self.usernameText.text!)
                     dbRef.setValue(userAccount), withCompletionBlock: { (error, ref) in
                     if let error = error {
                     print(error.localizedDescription)
                     let alertController = UIAlertController(title: "Error", message: error.localizedDescription, preferredStyle: .alert)
                     let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                     alertController.addAction(defaultAction)
                     self.present(alertController, animated: true, completion: nil)
                     }else {
                     print("Woo!")
                     self.performSegue(withIdentifier: "SignUpSuccessSegue", sender: self)
                     }
                     })
                     }
                     }
                     }*/
                }
            }
        }
    }
    
}
