//
//  SignInViewController.swift
//  NYU-Buzz
//
//  Created by Sai on 5/2/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit
import Firebase
import FirebaseAuth

class SignInViewController: UIViewController {
    
    @IBOutlet weak var emailText: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var logInButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        let tap = UITapGestureRecognizer(target: self.view, action: #selector(UIView.endEditing(_:)))
        tap.cancelsTouchesInView = false
        self.view.addGestureRecognizer(tap)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        if(Auth.auth().currentUser != nil) {
            
            //self.performSegue(withIdentifier: "SignInSuccessSegue", sender: self)
        }
    }
    
    @IBAction func logInPressed(_ sender: Any) {
        login()
    }
    
    func login() {
        if (self.emailText.text == "" || self.passwordText.text == "") {
            let alertController = UIAlertController(title: "Error", message: "Please enter an email and password.", preferredStyle: .alert)
            
            let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
            alertController.addAction(defaultAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
        else {
            Auth.auth().signIn(withEmail: self.emailText.text!, password: self.passwordText.text!) { (user, error) in
                
                if error == nil {
                    //var curUser: UserAccount!
                    //var snap: DataSnapshot?
                    //Print into the console if successfully logged in
                    let email = self.emailText.text!
                    var newEmail = ""
                    for index in email.indices {
                        if(email[index] == "@" || email[index] == ".") {
                            //skip
                        }
                        else{
                            newEmail = newEmail + String(email[index])
                        }
                    }
                    print("You have successfully logged in")
                    let dbRef = Database.database().reference().child("users").child(newEmail)
                    dbRef.observeSingleEvent(of: .value, with: { (snapshot: DataSnapshot) in
                            let currentUser = UserAccount(snap: snapshot)
                            //print(currentUser.email, currentUser.key, currentUser.username)
                        /*currentUserArr.append(currentUser)
                        do{
                            let encoded = try NSKeyedArchiver.archivedData(withRootObject: currentUserArr, requiringSecureCoding: false)
                            UserDefaults.standard.set(encoded, forKey: "currentUser")
                            UserDefaults.standard.synchronize()
                        } catch {
                            print("error")
                        }
                        //(withRootObject: currentUset)*/
                        
                    }) { (error) in
                        print(error.localizedDescription)
                    }
                    
                    self.performSegue(withIdentifier: "SignInSuccessSegue", sender: self)
                    
                }
                else {
                    
                    //Tells the user that there is an error and then gets firebase to tell them the error
                    let alertController = UIAlertController(title: "Error", message: error?.localizedDescription, preferredStyle: .alert)
                    
                    let defaultAction = UIAlertAction(title: "OK", style: .cancel, handler: nil)
                    alertController.addAction(defaultAction)
                    
                    self.present(alertController, animated: true, completion: nil)
                }
            }
        }
    }
    //PrepareforSegue
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
}

