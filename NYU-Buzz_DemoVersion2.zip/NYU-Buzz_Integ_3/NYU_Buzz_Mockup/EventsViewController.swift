//
//  EventsViewController.swift
//  NYU_Buzz_Mockup
//
//  Created by Rahayma Sheikh on 5/3/19.
//  Copyright © 2019 nyu.edu. All rights reserved.
//

import UIKit

class EventsViewController: UIViewController {
    
    
    @IBOutlet weak var numCurrentTokens: UILabel!
    @IBOutlet weak var usernameLabel: UILabel!
    
    var events:[eventInfo] = []
    
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let tabBar = tabBarController as! BaseTabBarController
        print(String(tabBar.myTokens))
        numCurrentTokens.text = String(tabBar.myTokens)
        usernameLabel.text = tabBar.myUsername
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
    }
    
    // Show the current number of rewards for the user
    override func viewDidAppear(_ animated: Bool) {
        let tabBar = tabBarController as! BaseTabBarController
        numCurrentTokens.text = String(tabBar.myTokens)
    }
    
    
    
    @IBAction func addButtonTapped(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let controller = storyboard.instantiateViewController(withIdentifier: "AddEventViewController") as! AddEventViewController
        controller.delegate = self
        
        self.present(controller, animated: true, completion: nil)
    }
}

extension EventsViewController:AddEventViewControllerDelegate{
    func sendEvent(event: eventInfo) {
        let tabBar = tabBarController as! BaseTabBarController
        // self.events.append(event)
        tabBar.eventObjArray.append((event))
        self.tableView.reloadData()
    }
    
    
}

extension EventsViewController:UITableViewDelegate,UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let tabBar = tabBarController as! BaseTabBarController
        return tabBar.eventObjArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Home_TableViewCell", for: indexPath) as!  Home_TableViewCell
        let tabBar = tabBarController as! BaseTabBarController
        cell.model  = tabBar.eventObjArray[indexPath.row] as! eventInfo
        cell.imageSelected = (tabBar.eventObjArray[indexPath.row] as! eventInfo).imageSelected
        cell.initialise(model: tabBar.eventObjArray[indexPath.row] as! eventInfo)
        cell.delegate = self
        cell.indexPath  = indexPath
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        
        if editingStyle == UITableViewCell.EditingStyle.delete {
            events.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: UITableView.RowAnimation.automatic)
        }
        
        
        
    }
}

extension EventsViewController:cellDelegate{
    func changeModelValue(value: Bool,indexPath:IndexPath) {
        //events[indexPath.row].setImageSelected(value: value)
        let tabBar = tabBarController as! BaseTabBarController
        (tabBar.eventObjArray[indexPath.row] as! eventInfo).imageSelected = value
        let affectedEventObj: eventInfo = tabBar.eventObjArray[indexPath.row] as! eventInfo
        print("affectedEventObj is " + affectedEventObj.name)
        
        // if imageSelected is true, then add it to our favorites
        if (value == true) {
            print("adding " + affectedEventObj.name + " to favorites")
            tabBar.favoriteEvents.append(affectedEventObj)
        }
        
        // if imageSelected is false, then take it away from our favorites
        else {
            print("taking away " + affectedEventObj.name + " from favorites")
            for (index, favEvent) in tabBar.favoriteEvents.enumerated() {
                if ((favEvent as! eventInfo).name == affectedEventObj.name) {
                    print("removing event " + (favEvent as! eventInfo).name)
                    tabBar.favoriteEvents.remove(at: index)
                }
            }
        }
        
        /*
        (self.tabBarController?.viewControllers?[0] as! HomeViewController).events  = events.filter({ (model) -> Bool in
            return model.imageSelected == true
        }) */
        
        (self.tabBarController?.viewControllers?[0] as! HomeViewController).tableView.reloadData()
        
    }
}
